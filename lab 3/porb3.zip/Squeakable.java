// Squeakable.java
public interface Squeakable {
    void squeak();
}
