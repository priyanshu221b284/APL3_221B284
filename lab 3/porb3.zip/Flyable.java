// Flyable.java
public interface Flyable {
    void fly();
}
