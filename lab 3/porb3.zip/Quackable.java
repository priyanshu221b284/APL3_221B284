// Quackable.java
public interface Quackable {
    void quack();
}
