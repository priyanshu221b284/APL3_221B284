// Swimmable.java
public interface Swimmable {
    void swim();
}
