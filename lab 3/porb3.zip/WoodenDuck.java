// WoodenDuck.java
public class WoodenDuck extends Duck {
    WoodenDuck(String name) {
        super(name);
    }
}
